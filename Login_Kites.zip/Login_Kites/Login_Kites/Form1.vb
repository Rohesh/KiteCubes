﻿Imports System.Data.SqlClient
Public Class Form1


    Dim con As SqlConnection = New SqlConnection("Data Source=.;Initial Catalog=master;Integrated Security=True")
    Dim cmd As SqlCommand

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If con.State = ConnectionState.Open Then con.Close()
        con.Open()
        If TextBox1.Text = "" Then
            MsgBox("Enter UserName..", MsgBoxStyle.Critical)
        ElseIf TextBox2.Text = "" Then
            MsgBox("Enter Password..", MsgBoxStyle.Critical)
        ElseIf TextBox3.Text = "" Then
            MsgBox("Enter UserType..", MsgBoxStyle.Critical)
        Else
            Dim query As String
            query = "select * from tblLogin where UserName='" + TextBox1.Text + "' and Password='" + TextBox2.Text + "' and Type='" + TextBox3.Text + "'"
            cmd = New SqlCommand(query, con)
            Dim da As SqlDataAdapter = New SqlDataAdapter(cmd)
            Dim ds As DataSet = New DataSet()
            da.Fill(ds)
            Dim a As Integer
            a = ds.Tables(0).Rows.Count
            If a = 0 Then
                MsgBox("Login Fail Please Enter UserName ,Password and Type..", MsgBoxStyle.Critical)
            ElseIf TextBox3.Text = "ADMIN" Then
                adminHome.Show()
                Me.Hide()
            ElseIf TextBox3.Text = "User" Then
                userHome.Show()
                Me.Hide()
                'Else
                '    adminHome.Show()
                '    Me.Hide()

            End If
        End If
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) 

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        register.Show()
        Me.Hide()
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub
End Class
