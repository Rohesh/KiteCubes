﻿Imports System.Data.SqlClient
Imports System.Net.Mail


Public Class SendMail
    Private Sub ButtonSend_Click(sender As Object, e As EventArgs) Handles ButtonSend.Click
        Try
            Dim smtp_server As New SmtpClient
            Dim email As New MailMessage
            smtp_server.UseDefaultCredentials = False
            smtp_server.Credentials = New Net.NetworkCredential("rohesh16@gmail.com", "teenacookie1610")
            smtp_server.Port = 587
            smtp_server.EnableSsl = True
            smtp_server.Host = "smtp.gmail.com"
            email = New MailMessage()
            'email.From = New MailAddress(TextBoxFrom.Text)
            'email.To.Add(TextBoxto.Text)
            'email.Subject = TextBoxSubject.Text
            'email.Body = TextBox2Msg.Text
            email.From = New MailAddress("rohesh16@gmail.com")
            email.To.Add("teenacookie16@gmail.com")
            email.Subject = "hi"
            email.Body = "Hey"
            smtp_server.Send(email)
            MsgBox("Mail Sent,Thank you")



        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class