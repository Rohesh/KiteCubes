﻿Imports System.Data.SqlClient
Imports System.Net.Mail

Public Class register
    Dim con As SqlConnection = New SqlConnection("Data Source=.;Initial Catalog=master;Integrated Security=True")
    Dim cmd As SqlCommand
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If con.State = ConnectionState.Open Then con.Close()
        con.Open()
        Dim query As String = ""
        query = ("insert into tblLogin values ('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox2.Text & "')")

        cmd = New SqlCommand(query, con)
        Dim a As Integer
        a = cmd.ExecuteNonQuery()
        If a = 0 Then
            MsgBox("error")
        Else
            MsgBox("Account Created Successfully ...", MsgBoxStyle.Information)

        End If
        con.Close()
        'SendMail.Show()
        Try
            Dim smtp_server As New SmtpClient
            Dim email As New MailMessage
            smtp_server.UseDefaultCredentials = False
            smtp_server.Credentials = New Net.NetworkCredential("MymailID", "MyPassword") 'MailID and Password to be provided
            smtp_server.Port = 587
            smtp_server.EnableSsl = True
            smtp_server.Host = "smtp.gmail.com"
            email = New MailMessage()
            'email.From = New MailAddress(TextBoxFrom.Text)
            'email.To.Add(TextBoxto.Text)
            'email.Subject = TextBoxSubject.Text
            'email.Body = TextBox2Msg.Text
            email.From = New MailAddress("") 'From Mail ID
            email.To.Add("") ' TO Mail ID
            email.Subject = "" 'Subject
            email.Body = "" 'Body
            smtp_server.Send(email)
            MsgBox("Mail Sent successfully ,Thank you for registering with us")



        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    'Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
    '    SendMail.Show()
    'End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Application.Exit()
    End Sub
End Class