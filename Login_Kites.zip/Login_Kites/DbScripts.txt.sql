
//Table for login ..

create table tblLogin
(
UserName varchar(50),
Password varchar(50),
Type varchar(50)
);



// Login Users

INSERT INTO tblLogin (UserName, Password, Type)
VALUES ('Rohesh', '12345', 'User');


INSERT INTO tblLogin (UserName, Password, Type)
VALUES ('coder', '12345', 'ADMIN');


* UserType must be "ADMIN" or "User".
* From , To mail address to be provided in the code for testing

